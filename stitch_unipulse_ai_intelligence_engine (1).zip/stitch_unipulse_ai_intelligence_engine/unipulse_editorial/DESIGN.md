---
name: UniPulse Editorial
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#c8c7be'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#929189'
  outline-variant: '#474740'
  surface-tint: '#c9c6c0'
  primary: '#ffffff'
  on-primary: '#31312c'
  primary-container: '#e5e2db'
  on-primary-container: '#65645f'
  inverse-primary: '#5f5e59'
  secondary: '#c8c6c5'
  on-secondary: '#313030'
  secondary-container: '#474746'
  on-secondary-container: '#b7b4b4'
  tertiary: '#ffffff'
  on-tertiary: '#2e321f'
  tertiary-container: '#e1e5c9'
  on-tertiary-container: '#626750'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e5e2db'
  primary-fixed-dim: '#c9c6c0'
  on-primary-fixed: '#1c1c18'
  on-primary-fixed-variant: '#474742'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#e1e5c9'
  tertiary-fixed-dim: '#c4c9ae'
  on-tertiary-fixed: '#191d0c'
  on-tertiary-fixed-variant: '#444934'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-lg:
    fontFamily: EB Garamond
    fontSize: 84px
    fontWeight: '400'
    lineHeight: 92px
    letterSpacing: -0.02em
  display-sm:
    fontFamily: EB Garamond
    fontSize: 56px
    fontWeight: '400'
    lineHeight: 64px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: EB Garamond
    fontSize: 40px
    fontWeight: '400'
    lineHeight: 48px
  headline-lg-mobile:
    fontFamily: EB Garamond
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 38px
  metric-xl:
    fontFamily: EB Garamond
    fontSize: 112px
    fontWeight: '400'
    lineHeight: 112px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 32px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  section-gap: 120px
  element-gap: 48px
  container-padding: 64px
  sidebar-width: 280px
---

## Brand & Style
The design system embodies a premium, intellectual atmosphere characterized by **Dark Editorial Minimalism**. It shifts away from standard SaaS patterns toward high-end digital publishing. The target audience values sophistication, precision, and quiet authority.

The aesthetic utilizes a **Tactile Paper** approach within a dark mode environment. Surfaces should feel like heavy, textured cardstock rather than digital panels. The emotional response is one of calm confidence, achieved through expansive negative space, asymmetric balance, and a focus on "storytelling through data" rather than raw utility.

## Colors
The palette is rooted in an ultra-dark neutral base to provide a sense of infinite depth.
- **Primary (#F4F1EA):** Used for primary typography and essential branding. It is an off-white that avoids the harshness of pure white, simulating aged paper or bone.
- **Secondary & Surface:** Used for layered "sheets" of content. Surface (#202020) should be reserved for the highest elevated elements.
- **Accents:** Muted Olive, Steel Blue, and Terracotta are used sparingly (less than 5% of the UI) for status indicators, data visualization categories, or subtle call-to-actions.
- **Muted Gray (#A6A39C):** The workhorse for secondary information and metadata to maintain high-end hierarchy.

## Typography
Typography is the primary structural element of this design system. 
- **EB Garamond** is the voice of the system. Use it for oversized metrics, intros, and high-level headings. It should never be used for small UI labels or dense data.
- **Inter** provides the technical "skeleton." It handles all functional UI, navigation, and detailed data points.
- **Hierarchy:** Ensure a stark contrast between display text and body text. Use `metric-xl` for single, impactful data points surrounded by ample negative space.

## Layout & Spacing
The layout follows an **Asymmetric Editorial** model. Avoid standard 3-column grids; instead, use a 12-column underlying grid but allow elements to "bleed" or sit off-center to create visual interest.

- **Margins:** Large 64px horizontal margins on desktop to prevent content from feeling crowded.
- **Negative Space:** Use `section-gap` between major content blocks. Information density should be kept low to maintain the premium feel.
- **Mobile:** Transition to a single-column flow, but maintain the large typography for headings to keep the brand's confident "voice."

## Elevation & Depth
Depth is conveyed through **Stacked Sheets** and subtle tonal shifts rather than aggressive shadows.
- **Tonal Layers:** The background is #111111. Secondary content areas sit on #181818. Active or interactive "cards" sit on #202020.
- **Shadows:** Use extremely soft, large-radius shadows (Blur: 40px, Opacity: 30%) with a slight #000000 tint to give the impression of paper floating slightly above a surface.
- **Borders:** Use very thin (1px), low-opacity strokes (#FFFFFF at 5-10% opacity) for dividers and component edges to define shape without breaking the dark immersion.

## Shapes
The shape language is **Structured and Precise**. 
- Elements use a "Soft" (0.25rem) radius to prevent a clinical feel, but they remain sharp enough to feel architectural. 
- Large containers or "sheets" should use the standard radius. 
- Avoid fully rounded "pill" shapes for buttons; use the subtle 0.25rem radius instead to maintain the editorial aesthetic.

## Components
- **Buttons:** Use a ghost-style approach for secondary actions (thin border, primary text). For primary actions, use a solid #F4F1EA background with #111111 text.
- **Input Fields:** Bottom-border only or very subtle #181818 fills. Typography should be Inter 15px.
- **Metrics:** Display large numbers in EB Garamond. Accompany them with a small `label-caps` subtitle in Inter.
- **Cards:** Do not use traditional "boxed" cards with heavy borders. Use tonal shifts (#181818 backgrounds) and generous internal padding (40px+) to define content areas.
- **Progress Indicators:** Use the muted accent colors (Olive or Steel Blue) in very thin 2px lines to indicate status or completion.
- **Imagery:** Use high-contrast, moody photography or brushed metal textures as background accents to reinforce the tactile nature of the system.